export const errorBooks = error => {
	console.error(error)
}

export const errorCategoryBooks = error => {
	console.error('Error fetching category books:', error)
}