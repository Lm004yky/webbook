export const openSignUp = document.querySelector('.btn-signup');
export const userInfo = document.querySelector('.user-info');
export const btnProfile = document.querySelector('.btn-profile');
export const hederBurger = document.querySelector('#open-button-menu');
export const closeModal = document.querySelector('.modal-close-js');
export const authModal = document.querySelector('.auth-modal-js');
export const btnSubmit = document.querySelector('.form--btn-submit');
export const btnSignUp = document.querySelector('.form__btn-sign-up');
export const btnSignIn = document.querySelector('.form__btn-sign-in');
export const formInputAdd = document.querySelector('.form-add');
export const inputName = document.querySelector('.form-input-name');
export const mobileMenu = document.querySelector('.mobile-menu');
export const singBtnOut = document.querySelector('.sign-out-btn-js');
export const signOutButton = document.querySelector('#signOutButton');
export const settingsUser = document.getElementById('settingsUser');
export const passwordInput = document.querySelector('.input-password-js');
export const checkAuthOpen = document.querySelector('.input-psw-open');
export const iconLookPasswork = document.querySelector('.icon-lock-auth');
export const iconEye = document.querySelector('.icon-eye');
export const iconEyeSlash = document.querySelector('.icon-eye-slash');
export const svgEye = document.querySelector('.svg-eye');
export const formInputName = document.querySelector('.form-input-name');
export const userEmail = document.getElementById('userEmail');
export const userPassword = document.getElementById('userPassword');
export const authForm = document.querySelector('form#authForm');

// auth-script.js |some exports are taken above to avoid repetition

export const signUpButton = document.querySelector('#signUpButton');
export const formBtnSubmit = document.querySelector('.form--btn-submit');
export const userBtnInfo = document.querySelector('.user-info');
export const signUpBtn = document.querySelector('.btn-signup');
export const modalWindow = document.querySelector('.modal-js');
export const modalBooks = document.querySelector('.modal');
export const backdropAuth = document.querySelector('.backdrop-auth');

